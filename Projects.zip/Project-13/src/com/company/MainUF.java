package com.company;

public class MainUF {

    public static void main(String[] args) {
        UF arr = new UF();
        arr.connect(0,1);
    }
}
