package com.company;

public class Pivot {

    public void pivot(char[] arr) {
        char pivot = arr[0];
        System.out.println("Pivot: " + pivot);
    }
}
