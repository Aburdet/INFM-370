package com.company;

public class am {

    public static void main(String[] args) {
        String[] first = {"Top", "Great", "Glory"};
        for(String i:first) {
            System.out.println(i);
            System.out.println("Hello");
        }
    }
}
