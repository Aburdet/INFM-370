package com.company;

public class Main {

    public static void main(String[] args) {
        int[] arr = {1,1,4,4,4,1};
        System.out.println(arr[0]);
        System.out.println(arr[1]);
        System.out.println(arr[2]);
        System.out.println(arr[3]);
    }
}
