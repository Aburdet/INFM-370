package com.company;

public class Main {

    public static void main(String[] args) {
        int[] arr = {55,1000,-66,-1};
        System.out.println(arr[0]);
        System.out.println(arr[1]);
        System.out.println(arr[2]);
        System.out.println(arr[3]);
    }
}
