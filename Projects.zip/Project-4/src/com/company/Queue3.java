package com.company;

public class Queue3 {
    int[] queue = new int[7];
    int index = 0;
    public void enqueue(int value) {

    }
}
