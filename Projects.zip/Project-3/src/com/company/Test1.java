package com.company;

public class Test1 {
    public void add() {
        int a=1;
        a++;
    }
    public void ded() {
        int a=1;
        a--;
    }
    public int print() {
        int a=1;
        return a;
    }
}
