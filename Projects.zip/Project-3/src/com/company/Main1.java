package com.company;

public class Main1 {
    public static void main(String[] args) {
        Test1 test = new Test1();
        test.add();
        test.add();
        test.ded();
        System.out.println(test.print());
    }
}
