/*
Adam Burdett
Dr. Milad
INFM 370
31 August 2021
*/
package com.company;

public class Main {

    public static void main(String[] args) {
        Test test1 = new Test();
        test1.add();
        test1.add();
        test1.ded();
        Test test2 = new Test();
        System.out.println(test2.print());
    }
}
