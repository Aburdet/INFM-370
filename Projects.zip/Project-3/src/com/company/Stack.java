package com.company;

import java.lang.reflect.Array;

public class Stack {
    Array array;
    int index=0;
    public Array push(String item) {
        array.equals(item);
        return array;
    }
    public void pop() {

    }
    public void peek() {

    }
    public void top() {

    }
    public void isEmpty() {

    }
}
