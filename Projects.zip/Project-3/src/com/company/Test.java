package com.company;

public class Test {
    int a=1;
    public void add() {
        a++;
    }
    public void ded() {
        a--;
    }
    public int print() {
        return a;
    }
}
